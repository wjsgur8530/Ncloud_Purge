from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError
from flask import Flask, request, make_response
import logging
import hashlib
import hmac
import base64
import requests
import time
import json

app = Flask(__name__)

client = WebClient(token="your-bot-token")

# Ncloud 내 계정 루트
access_key = 'your api access key'
secret_key = 'your api secret key'

# 캐시 관련 헤더를 제거하는 함수
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response

# after_request 데코레이터를 사용하여 모든 응답에 대해 캐시 관련 헤더를 제거
@app.after_request
def apply_caching(response):
    return after_request(response)

class NcloudApiClient:
    def __init__(self, access_key, secret_key):
        self.access_key = access_key
        self.secret_key = bytes(secret_key, 'UTF-8')
        self.api_server = "https://edge.apigw.ntruss.com"

    def make_signature(self, uri, method="POST"):
        timestamp = str(int(time.time() * 1000))

        message = method + " " + uri + "\n" + timestamp + "\n" + self.access_key
        message = bytes(message, 'UTF-8')

        signingKey = base64.b64encode(hmac.new(self.secret_key, message, digestmod=hashlib.sha256).digest())
        api_endpoint = self.api_server + uri
        http_header = {
            'x-ncp-apigw-signature-v2': signingKey,
            'x-ncp-apigw-timestamp': timestamp,
            'x-ncp-iam-access-key': self.access_key
        }

        return api_endpoint, http_header

    def get_request(self, uri):
        api_endpoint, http_header = self.make_signature(uri, method="GET")

        response = requests.get(api_endpoint, headers=http_header, json={})
        return json.loads(response.text)

    def post_request(self, uri, edge_id, edge_profile_id):
        api_endpoint, http_header = self.make_signature(uri, method="POST")
        data = {
            "edgeId": edge_id,
            "profileId": edge_profile_id,
            "purgeType": "ALL"
        }
        response = requests.post(api_endpoint, headers=http_header, json=data)
        return json.loads(response.text)

    def getProfileList(self):
        # Profile 목록 조회
        profileListData = self.get_request("/api/v1/profiles")
        
        # 전체 ProfileData 배열에서 id 값만 추출해서 배열화
        profile_id_list = [profile_data['id'] for profile_data in profileListData['result']]
        return profile_id_list

    def getEdgeList(self):
        profileId = self.getProfileList()

        edgeListData = []
        for edge_data in profileId:
            # Edge 목록 조회
            edgeListData.append(self.get_request("/api/v1/profiles/" + str(edge_data) + "/cdn-edges"))
        
        # 전체 EdgeData 배열에서 result 값만 추출해서 배열화
        result_list = [item['result'] for item in edgeListData if 'result' in item]
        result_list = [result_data for sublist in result_list for result_data in sublist]

        print(result_list)

        # 필요한 edge 데이터 추출해서 배열화
        edge_name_list = [edge_data['edgeName'] for edge_data in result_list]
        edge_status_list = [edge_data['statusType'] for edge_data in result_list]
        edge_id_list = [edge_data['id'] for edge_data in result_list]
        edge_profile_id_list = [edge_data['profileId'] for edge_data in result_list]
        return edge_name_list, edge_status_list, edge_id_list, edge_profile_id_list
    
    def purgeRequest(self, edge_id, edge_profile_id):
        response = self.post_request("/api/v1/purge", edge_id, edge_profile_id)

        if response['message'] == 'Success':
            postChatToSlackPurgeMessage('Success')
        elif response['message'] == 'Unauthorized':
            postChatToSlackPurgeMessage('Unauthorized')
        else:
            postChatToSlackPurgeMessage('Internal Server Error')

        return {
            "statusCode": 200
        }

def main():
    slack_event = json.loads(request.data)
    if "challenge" in slack_event:
        return make_response(slack_event["challenge"], 200, {"content_type": "application/json"})

    if slack_event["event"]["type"] == "app_mention":
        postChatToSlack()
        return {
            "statusCode": 200,
            'headers': {'Content-Type': 'application/json'},
            "body": {
                "slack_event": slack_event
            }
        }
    else:
        return {
            "statusCode": 200,
            'Content-Type': 'application/json',
        }

def slackInteractiveActions():
    payload = json.loads(request.form.get("payload"))
    ncloud_api = NcloudApiClient(access_key, secret_key)

    # actions 배열 확인
    for action in payload.get("actions", []):
        if action["type"] == "overflow" and "selected_option" in action:
            selected_option = action["selected_option"]
            value = selected_option.get("value")
    
    split_values = value.split('/')
    # Edge id / profile id
    edge_id = split_values[0]
    edge_profile_id = split_values[1]

    ncloud_api.purgeRequest(edge_id, edge_profile_id)

    return {
        "statusCode": 200,
        'Content-Type': 'application/json',
    }

def postChatToSlackPurgeMessage(purgeStatus):
    client.chat_postMessage(
        channel="C06NN5P2P7F",
        text="Purge 결과: " + purgeStatus
    )

def postChatToSlack():
    client.chat_postMessage(
        channel="C06NN5P2P7F",
        text="네이버 클라우드 플랫폼",
        blocks=postChatToSlackBlocks()
    )

def postChatToSlackBlocks():
    # Ncloud 내 계정 루트
    ncloud_api = NcloudApiClient(access_key, secret_key)
    edge_name_list, edge_status_list, edge_id_list, edge_profile_id_list = ncloud_api.getEdgeList()
    blocks = [
        {
			"type": "image",
			"image_url": "https://img.etnews.com/photonews/1706/969787_20170630150258_096_0001.jpg",
			"alt_text": "image1",
		},
        {
			"type": "section",
			"text": {
				"type": "mrkdwn",
				"text": ">:mag: *Global Edge를 선택하셨습니다. Edge 정보입니다.*"
			},
		},
    ] + [
        {
            "type": "context",
            "elements": [
                {
                    "type": "mrkdwn",
                    "text": "*ID*"
                },
                {
                    "type": "mrkdwn",
                    "text": "*Profile ID*"
                },
                {
                    "type": "mrkdwn",
                    "text": "*Name*"
                },
                {
                    "type": "mrkdwn",
                    "text": "*Status*"
                }
            ],
        },
    ] + [
            {
                "type": "section",
                "text": {
                        "type": "mrkdwn",
                        "text": str(i) + "  " + str(j) + "  " + k + "  " + l,
                },
                "accessory": {
                        "type": "overflow",
                        "options": [
                                {
                                        "text": {
                                                "type": "plain_text",
                                                "text": "*Purge*",
                                                "emoji": True
                                        },
                                        "value": str(i) + "/" + str(j)
                                },
                                {
                                        "text": {
                                                "type": "plain_text",
                                                "text": "*Purge Logs*",
                                                "emoji": True
                                        },
                                        "value": str(i) + "/" + str(j)
                                }
                        ],
                        "action_id": "purge-action"
                    }
            } for index, (i, j, k, l) in enumerate(zip(edge_id_list, edge_profile_id_list, edge_name_list, edge_status_list))
    ]

    return blocks